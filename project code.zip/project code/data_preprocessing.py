import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler


def load_data(filepath: str) -> pd.DataFrame:
    """Load the diabetes CSV dataset."""
    df = pd.read_csv(filepath)
    print("Dataset Shape:", df.shape)
    print("Columns:", list(df.columns))
    df.info()
    print("\nMissing Values:\n", df.isnull().sum())
    return df


def fix_zero_values(df: pd.DataFrame) -> pd.DataFrame:
    """Replace biologically impossible zero values with column mean."""
    cols = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
    for col in cols:
        df[col] = df[col].replace(0, df[col].mean())
    print("Zero values replaced with column means for:", cols)
    return df


def split_features_target(df: pd.DataFrame):
    """Split dataframe into features (X) and target (y)."""
    X = df.drop('Outcome', axis=1)
    y = df['Outcome']
    return X, y


def scale_features(X: pd.DataFrame):
    """Standardize features using StandardScaler."""
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, scaler


if __name__ == "__main__":
    df = load_data("diabetes.csv")
    df = fix_zero_values(df)
    X, y = split_features_target(df)
    X_scaled, scaler = scale_features(X)
    print("\nPreprocessing complete. X_scaled shape:", X_scaled.shape)
