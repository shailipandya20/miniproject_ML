import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def plot_outcome_distribution(df: pd.DataFrame):
    """Bar chart of diabetes vs non-diabetes counts."""
    sns.countplot(x=df['Outcome'])
    plt.title("Diabetes Distribution (0 = No, 1 = Yes)")
    plt.tight_layout()
    plt.savefig("outcome_distribution.png")
    plt.show()
    print("Saved: outcome_distribution.png")


def plot_correlation_heatmap(df: pd.DataFrame):
    """Heatmap of feature correlations."""
    plt.figure(figsize=(8, 6))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("correlation_heatmap.png")
    plt.show()
    print("Saved: correlation_heatmap.png")


if __name__ == "__main__":
    from data_preprocessing import load_data, fix_zero_values

    df = load_data("diabetes.csv")
    df = fix_zero_values(df)
    plot_outcome_distribution(df)
    plot_correlation_heatmap(df)
