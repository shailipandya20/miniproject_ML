from data_preprocessing import load_data, fix_zero_values, split_features_target, scale_features
from eda import plot_outcome_distribution, plot_correlation_heatmap
from model_training import split_data, train_logistic_regression, train_random_forest, tune_random_forest, evaluate_model
from visualizations import plot_feature_importance, plot_model_comparison, plot_confusion_matrix


def main():
    # 1. Load & Preprocess 
    print("=" * 50)
    print("STEP 1: Loading & Preprocessing Data")
    print("=" * 50)
    df = load_data("diabetes.csv")
    df = fix_zero_values(df)

    # 2. EDA 
    print("\n" + "=" * 50)
    print("STEP 2: Exploratory Data Analysis")
    print("=" * 50)
    plot_outcome_distribution(df)
    plot_correlation_heatmap(df)

    # 3. Prepare Data 
    X, y = split_features_target(df)
    X_scaled, scaler = scale_features(X)
    X_train, X_test, y_train, y_test = split_data(X_scaled, y)

    # 4. Train Models
    print("\n" + "=" * 50)
    print("STEP 3: Training Models")
    print("=" * 50)
    lr = train_logistic_regression(X_train, y_train)
    lr_pred, lr_acc = evaluate_model(lr, X_test, y_test, "Logistic Regression")

    rf = train_random_forest(X_train, y_train)
    rf_pred, rf_acc = evaluate_model(rf, X_test, y_test, "Random Forest")

    # 5. Hyperparameter Tuning 
    print("\n" + "=" * 50)
    print("STEP 4: Hyperparameter Tuning (Random Forest)")
    print("=" * 50)
    best_rf, best_params = tune_random_forest(X_train, y_train)
    best_rf_pred, best_rf_acc = evaluate_model(best_rf, X_test, y_test, "Tuned Random Forest")

    # 6. Visualize Results 
    print("\n" + "=" * 50)
    print("STEP 5: Results & Visualizations")
    print("=" * 50)
    plot_feature_importance(rf, X.columns)
    plot_model_comparison(
        ['Logistic Regression', 'Random Forest'],
        [lr_acc, rf_acc]
    )
    plot_confusion_matrix(y_test, rf_pred)

    print("\n✅ Pipeline complete! All charts saved as PNG files.")


if __name__ == "__main__":
    main()
