import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix


def plot_feature_importance(rf_model, feature_names):
    """Bar chart of Random Forest feature importances."""
    importances = rf_model.feature_importances_
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importances
    }).sort_values(by='Importance', ascending=False)

    print("\nFeature Importances:\n", importance_df.to_string(index=False))

    plt.figure(figsize=(8, 5))
    sns.barplot(data=importance_df, x='Importance', y='Feature', palette='viridis')
    plt.title("Feature Importances - Random Forest")
    plt.tight_layout()
    plt.savefig("feature_importance.png")
    plt.show()
    print("Saved: feature_importance.png")
    return importance_df


def plot_model_comparison(model_names: list, accuracies: list):
    """Bar chart comparing model accuracies."""
    plt.figure(figsize=(6, 4))
    plt.bar(model_names, accuracies, color=['steelblue', 'seagreen'])
    plt.ylabel("Accuracy")
    plt.title("Model Comparison")
    plt.ylim(0, 1)
    for i, acc in enumerate(accuracies):
        plt.text(i, acc + 0.01, f"{acc:.2%}", ha='center', fontsize=11)
    plt.tight_layout()
    plt.savefig("model_comparison.png")
    plt.show()
    print("Saved: model_comparison.png")


def plot_confusion_matrix(y_test, rf_pred):
    """Heatmap of the Random Forest confusion matrix."""
    cm = confusion_matrix(y_test, rf_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['No Diabetes', 'Diabetes'],
                yticklabels=['No Diabetes', 'Diabetes'])
    plt.title("Confusion Matrix - Random Forest")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png")
    plt.show()
    print("Saved: confusion_matrix.png")


if __name__ == "__main__":
    from data_preprocessing import load_data, fix_zero_values, split_features_target, scale_features
    from model_training import split_data, train_logistic_regression, train_random_forest, evaluate_model
    from sklearn.metrics import accuracy_score

    df = load_data("diabetes.csv")
    df = fix_zero_values(df)
    X, y = split_features_target(df)
    X_scaled, scaler = scale_features(X)
    X_train, X_test, y_train, y_test = split_data(X_scaled, y)

    lr = train_logistic_regression(X_train, y_train)
    lr_pred, lr_acc = evaluate_model(lr, X_test, y_test, "Logistic Regression")

    rf = train_random_forest(X_train, y_train)
    rf_pred, rf_acc = evaluate_model(rf, X_test, y_test, "Random Forest")

    plot_feature_importance(rf, X.columns)
    plot_model_comparison(['Logistic Regression', 'Random Forest'], [lr_acc, rf_acc])
    plot_confusion_matrix(y_test, rf_pred)
