import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report


def split_data(X_scaled, y, test_size=0.2, random_state=42):
    """Split scaled features into train/test sets."""
    return train_test_split(X_scaled, y, test_size=test_size, random_state=random_state)


def train_logistic_regression(X_train, y_train):
    """Train a Logistic Regression model."""
    lr = LogisticRegression()
    lr.fit(X_train, y_train)
    print("Logistic Regression trained.")
    return lr


def train_random_forest(X_train, y_train):
    """Train a Random Forest classifier."""
    rf = RandomForestClassifier()
    rf.fit(X_train, y_train)
    print("Random Forest trained.")
    return rf


def tune_random_forest(X_train, y_train):
    """Hyperparameter tuning for Random Forest using GridSearchCV."""
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [None, 5, 10]
    }
    grid = GridSearchCV(RandomForestClassifier(), param_grid, cv=5)
    grid.fit(X_train, y_train)
    print("Best Parameters:", grid.best_params_)
    return grid.best_estimator_, grid.best_params_


def evaluate_model(model, X_test, y_test, model_name="Model"):
    """Print accuracy and classification report for a model."""
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print(f"\n{model_name} Accuracy: {acc:.4f}")
    print(classification_report(y_test, preds))
    return preds, acc


if __name__ == "__main__":
    from data_preprocessing import load_data, fix_zero_values, split_features_target, scale_features

    df = load_data("diabetes.csv")
    df = fix_zero_values(df)
    X, y = split_features_target(df)
    X_scaled, scaler = scale_features(X)

    X_train, X_test, y_train, y_test = split_data(X_scaled, y)

    lr = train_logistic_regression(X_train, y_train)
    lr_pred, lr_acc = evaluate_model(lr, X_test, y_test, "Logistic Regression")

    rf = train_random_forest(X_train, y_train)
    rf_pred, rf_acc = evaluate_model(rf, X_test, y_test, "Random Forest")

    best_rf, best_params = tune_random_forest(X_train, y_train)
    best_rf_pred, best_rf_acc = evaluate_model(best_rf, X_test, y_test, "Tuned Random Forest")
